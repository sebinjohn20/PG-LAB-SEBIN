import csv
filename= "username.csv"
fields =[]
rows=[]
cf=open(filename,'r')
csvreader=csv.reader(cf)
fields=next(cf)
print(fields)
for r in csvreader:
    rows.append(r)
print(rows)
print("..........")
print("\nfirst 3 rows are:\n\n")
for r in rows[:3]:
    print(*r)
print("\n\nthe file content\n\n")
for sl in rows:
    for l in sl:
        #print(l)
        print(l," ")
        print()
cf.close()
