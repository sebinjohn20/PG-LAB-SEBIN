import calendar
mm = int(input("Enter month: "))
yy = int(input("Enter year: "))
print(calendar.month(yy,mm))     
print(calendar.calendar(2015))
