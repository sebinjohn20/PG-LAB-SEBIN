import math
print("the value of pi is",math.pi)
import math as m
print("the value of pi is",m.pi)
from math import pi,sqrt
print("the value of pi is ",pi)
print("the square root of 4 is ",sqrt(4))
print(math.cos(90))
print(math.sin(3))
print(math.tan(0))
