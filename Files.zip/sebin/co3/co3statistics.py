import statistics
list1 = [5,2,5,6,1,2,6,7,2,6,3,5,5]
x = statistics.mean(list1)
print(x)
y = statistics.median(list1)
print(y)
z = statistics.mode(list1)
print(z)
a = statistics.stdev(list1)
print(a)
b = statistics.variance(list1)
print(b)
