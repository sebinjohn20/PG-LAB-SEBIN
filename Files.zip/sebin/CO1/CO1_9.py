str=input("enter a string")
new_str=str[-1:]+str[1:-1]+str[:1]
print("new string:",new_str)
