pi=3.14
r=float(input("input the radius of circle:"))
result=3.14*r**2
print("the area of circLe with radius is:",result)
