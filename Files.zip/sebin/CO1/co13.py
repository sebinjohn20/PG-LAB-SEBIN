a=[]
for i in range(3):
    b=input("enter the color")
    a.append(b)
print(a)
print(a[0])
print(a[2])
    
