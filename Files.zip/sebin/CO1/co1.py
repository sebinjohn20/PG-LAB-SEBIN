n=int(input("enter limit:"))
squarelist=[i**2 for i in range(1,n+1)]
print("square of N numbers:",squarelist)


