file=input("enter filename:")
f=file.split(".")
print("extension of file is:"+f[-1])
