w=input("enter a word:")
print("ordinal values corresponding to each element is")
for i in w:
    print(i,end=":")
    print(ord(i),end=" ")
