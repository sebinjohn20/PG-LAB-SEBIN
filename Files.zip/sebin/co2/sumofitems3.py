list1=[10,15,20,25,30]
total=sum(list1)
print("sum of list:",total)
