list1=[-10,20,35,-67,70]
re=[num for num in list1 if num>=0]
print(re)
