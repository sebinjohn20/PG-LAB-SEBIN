color_list_1=set(["white","pink","red","blue"])
color_list_2=set(["red","green","pink"])
print(color_list_1.difference(color_list_2))
