a_list=("a","b","a")
occ=a_list.count("a")
print("count  of occurnces of a :",occ)
