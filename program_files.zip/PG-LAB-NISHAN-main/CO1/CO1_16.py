a="python"
b="java"
p1=a[0]
p2=b[0]
c=b[0]+a[1:len(a)]+" "+a[0]+b[1:len(b)]
print(a[1:len(a)])
print(c)

