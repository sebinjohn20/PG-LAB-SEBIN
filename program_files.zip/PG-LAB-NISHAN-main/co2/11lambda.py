import math
tarea=lambda b,h:1/2*b*h
rarea=lambda l,b:l*b
sarea=lambda a:a*a
print("area of triangle",tarea(10,20))
print("area of rectangle",rarea(30,20))
print("area of square",sarea(2))
