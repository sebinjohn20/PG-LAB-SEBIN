def areac(r):
    print("area of circle is",3.14*r*r)
    print("perimeter of circle is",2*3.14*r) 
 
