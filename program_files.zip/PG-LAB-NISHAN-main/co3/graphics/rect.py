def arear(l,b):
     print("area of rectangle is ",l*b)
     print("perimeter of rectangle is",2*(l+b))
