from graphics import rect
from graphics import circle
rect.arear(int(input("enter length of rectangle")),int(input("enter breadth of rectangle")))
circle.areac(int(input("enter radius of circle")))

